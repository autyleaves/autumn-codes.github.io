# AromaBot

The bot’s primary goal is to provide users with a unique experience exploring culinary recipes; in addition, it will provide users in a Discord server with discover, save, and share features. It aims to simplify the cooking experience for individuals by offering a comprehensive database of recipes and enabling users to search for recipes based on ingredients they have on hand and recipe names. The Aroma bot is unique because it implements game-like features such as achievement badges (roles), experience points (XP), leaderboards, recipe roulette, recipe quizzes, and social interaction. The Aroma bot will also promote seasonal recipes depending on the current season. 

[UPDATE] Forgot to include the sql file in the zip folder that was due this past Sunday. Just added it to the GitHub
.
