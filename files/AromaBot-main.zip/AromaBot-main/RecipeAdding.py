'''
Authors: Autumn Harrison & Jayden Davis
Date: 2023-11-07
Course: CSCI 2910 
Document Name: RecipeAdding.py

[Insert functions here]


'''

#this wont work because we'd have to create another bot instance
'''
@bot.command() 
    async def Aromarecipes(ctx): 
    await ctx.send(f"{ctx.author.mention} \n {meals}")
'''