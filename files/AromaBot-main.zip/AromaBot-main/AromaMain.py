'''
Authors: Autumn Harrison & Jayden Davis
Date: 2023-11-06
Course: CSCI 2910 
Document Name: AromaMain.py

This is the main python file for the main method? 



'''